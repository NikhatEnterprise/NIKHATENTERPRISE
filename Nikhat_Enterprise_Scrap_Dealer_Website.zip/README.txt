NIKHAT ENTERPRISE WEBSITE
==========================
Files:
- index.html
- style.css
- script.js

How to use:
1. Keep all three files in the same folder.
2. Open index.html in a browser to preview.
3. Upload the files to your hosting provider to publish the website.

Business details used:
Nikhat Enterprise
Old Scrap Dealer
41, Rafi Ahmed Kidwai Road, Kolkata - 700016, West Bengal
Phone/WhatsApp: 8825231304
Email: nikhatenteprise0786@gamil.com

Note: The email address has been kept exactly as provided. If "gamil.com" was a typo for "gmail.com", change it in index.html before publishing.
